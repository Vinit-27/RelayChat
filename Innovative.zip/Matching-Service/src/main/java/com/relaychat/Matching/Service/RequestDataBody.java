package com.relaychat.Matching.Service;

public class RequestDataBody {
    private String userId;
    private String id;

    public String getId() {
        return id;
    }
    public String getUserId() {
        return userId;
    }
}
