package com.relaychat.Session;

public class RequestDataBody  {
    private String sessionId;
    public String getSessionId() {
        return sessionId;
    }
}
