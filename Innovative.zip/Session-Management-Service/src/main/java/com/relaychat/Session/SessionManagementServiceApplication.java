package com.relaychat.Session;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessionManagementServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SessionManagementServiceApplication.class, args);
	}

}
