package com.relaychat.Session.Management.Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessionManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
